Ayam Panggang Express - ZIP (Simulasi)
Files:
- index.html
- manifest.json
- service-worker.js

Usage:
1. Extract the ZIP to a folder.
2. Serve via simple server (recommended) or open index.html in Chrome Android.
3. To fully test service worker, run a local server (python -m http.server) and open http://localhost:8000/index.html
4. Admin login: username=admin password=ayam123